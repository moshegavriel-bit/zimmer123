const CACHE_NAME = 'zimmerbyhour-v9.9.18-' + new Date().getTime();
const CORE_ASSETS = [
  '/manifest.json'
];
self.addEventListener('install', e => e.waitUntil(
  caches.open(CACHE_NAME).then(c =>
    Promise.all(CORE_ASSETS.map(url =>
      c.add(url).catch(err => console.warn('Failed to cache:', url))
    ))
  ).then(() => self.skipWaiting())
));
self.addEventListener('activate', e => e.waitUntil(
  caches.keys().then(k => Promise.all(
    k.filter(x => x !== CACHE_NAME).map(x => caches.delete(x))
  )).then(() => self.clients.claim())
));
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET' || e.request.url.includes('chrome-extension')) return;
  if (e.request.mode === 'navigate' || e.request.url.endsWith('.html') || e.request.url.endsWith('/')) {
    e.respondWith(fetch(e.request).catch(() => caches.match(e.request) || caches.match('/index.html')));
    return;
  }
  // תמונות - cache-first
  if (e.request.url.includes('/images/')) {
    e.respondWith(
      caches.match(e.request).then(cached => {
        if (cached) return cached;
        return fetch(e.request).then(response => {
          if (response.ok) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then(c => c.put(e.request, clone));
          }
          return response;
        });
      })
    );
    return;
  }
  e.respondWith(caches.match(e.request).then(c => c || fetch(e.request)));
});
